public class Hello{
    public static void main(String args[]){
        System.out.println("Maiuma linha"); 
        System.out.println("Ufa.. acho que agora vai!"); 
        System.out.println("Para de falar Isidro!!!!"); 
        System.out.println("Otra linha");
       
    }
}

