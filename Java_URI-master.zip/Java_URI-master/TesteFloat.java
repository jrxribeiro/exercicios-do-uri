public class TesteFloat{
    public static void main(String args[]){

        float r = 1.0f/2;

        System.out.println("Valor do r = "+r);
    }
}