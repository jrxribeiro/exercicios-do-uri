public class RepeteComFor{
    public static void main(String args[]){
        

        for (int contador=0; contador<=10; contador+=2){
            //if (contador %2 == 0){
                System.out.println("Contador = "+contador);
            //}
        }
    }
}